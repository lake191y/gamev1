class Options {
    useSkills: boolean = true;
    winningRank: number = 0;
    autoRecording: boolean = true;
}

const options = new Options();
export default options;

export interface BoxState {
    x: number,
    y: number,
    angle: number,
    width: number,
    height: number,
}
